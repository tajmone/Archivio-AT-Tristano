
Libro Game Creator

Scritto da Matteo Poropat

(C) 2007 Matteo Poropat (http://www.memoriedalbuio.com)

In collaborazione con Libro Game's Land (http://www.librogame.altervista.org)


Per qualsiasi informazione c'� il forum su http://librogamesland.proboards17.com/index.cgi?board=lgc


Questo programma permette la creazione e la gestione di semplici libri game. 

Per le caratteristiche e le novit� vedere changelog.txt.

Per la licenza d'uso vedere licenza.txt.

Per le FAQ del programma: http://www.memoriedalbuio.com/lgc_faq.html
